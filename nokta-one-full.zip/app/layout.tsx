import type { Metadata, Viewport } from "next";
import { Suspense } from "react";
import "./globals.css";
import { I18nProvider } from "@/components/providers/I18nProvider";
import { AuthProvider } from "@/components/providers/AuthProvider";
import AppProvider from "@/components/providers/AppProvider";
import ReferralTracker from "@/components/ReferralTracker";
import TestButtons from "@/components/debug/TestButtons";
import "@/lib/utils/console-filter"; // Filtrer les messages TensorFlow

// Police optionnelle - utiliser système si Google Fonts n'est pas disponible
let poppinsVariable = "";
try {
  const { Poppins } = require("next/font/google");
  const poppins = Poppins({ 
    subsets: ["latin"],
    weight: ["300", "400", "500", "600", "700"],
    variable: "--font-poppins",
    display: "swap",
    fallback: ["system-ui", "-apple-system", "BlinkMacSystemFont", "arial"],
  });
  poppinsVariable = poppins.variable;
} catch (e) {
  // Google Fonts non disponible, utiliser police système
  console.warn("Google Fonts not available, using system fonts");
}

export const metadata: Metadata = {
  title: "NOKTA ONE",
  description: "Nervous System Reset - 30 seconds to balance",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "NOKTA ONE",
  },
  formatDetection: {
    telephone: false,
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#0a0a0a",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" className={`dark ${poppinsVariable}`} dir="ltr" suppressHydrationWarning>
      <head>
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="HandheldFriendly" content="true" />
        <link rel="apple-touch-icon" href="/icons/icon-192.png" />
      </head>
      <body className={`antialiased bg-black text-white`} style={{ pointerEvents: 'auto', position: 'relative', margin: 0, padding: 0 }} suppressHydrationWarning>
        <I18nProvider>
          <AuthProvider>
            <AppProvider>
              <Suspense fallback={null}>
                <ReferralTracker />
              </Suspense>
              <TestButtons />
              <div className="app-container" style={{ pointerEvents: 'auto', position: 'relative' }}>
                <div className="landscape-warning fixed inset-0 bg-black z-[100] hidden items-center justify-center p-8 text-center pointer-events-none">
                  <div>
                    <p className="text-4xl mb-4"></p>
                    <p className="text-white text-lg">
                      Veuillez tourner votre téléphone en mode portrait
                    </p>
                  </div>
                </div>
                <main className="main-content" style={{ pointerEvents: 'auto', position: 'relative', zIndex: 10 }}>
                  {children}
                </main>
              </div>
            </AppProvider>
          </AuthProvider>
        </I18nProvider>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                function attachNavListeners() {
                  const navButtons = document.querySelectorAll('[data-nav-button]');
                  navButtons.forEach(btn => {
                    const path = btn.getAttribute('data-nav-path');
                    if (path) {
                      btn.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        window.location.href = path;
                      });
                    }
                  });
                }
                if (document.readyState === 'loading') {
                  document.addEventListener('DOMContentLoaded', attachNavListeners);
                } else {
                  attachNavListeners();
                }
                setTimeout(attachNavListeners, 100);
                setTimeout(attachNavListeners, 500);
              })();
            `,
          }}
        />
      </body>
    </html>
  );
}

"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { 
  Bell, Globe, Smartphone, UserPlus, HelpCircle, ChevronRight, BookOpen, 
  Edit2, MoreHorizontal, ChevronDown, MessageCircle, Shield, LogOut, Users, Download
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useTranslation } from "@/lib/hooks/useTranslation";
import { useSwipe } from "@/lib/hooks/useSwipe";
import i18n from "@/lib/i18n";
import { SafeAreaContainer } from "@/components/ui/SafeAreaContainer";
import { SettingsRow } from "@/components/settings/SettingsRow";
import LanguageModal from "@/components/modals/LanguageModal";
import { LANGUAGES } from "@/lib/i18n/languages";
import ComingSoonModal from "@/components/modals/ComingSoonModal";
import ConnectedDevicesModal from "@/components/modals/ConnectedDevicesModal";
import InvitationsModal from "@/components/modals/InvitationsModal";
import EditProfileModal from "@/components/modals/EditProfileModal";
import { SupportModal } from "@/components/modals/SupportModal";
import PrivacySettingsSection from "@/components/settings/PrivacySettingsSection";
import PartnershipSection from "@/components/settings/PartnershipSection";
import NotificationScheduler from "@/components/settings/NotificationScheduler";
import { createClient } from "@supabase/supabase-js";
import { calculateStreak, getMemberSince } from "@/lib/utils/profile-stats";

// Mock user data
const mockUser = {
  username: "nokta_one_user",
  email: "user@noktaone.app",
  referralCode: "@nokta_one_user-1234",
  firstName: "Benjamin",
  lastName: "Bel",
  dateOfBirth: "1993-01-15",
  gender: "Homme",
  phone: "+33612345678",
  address: "12 Rue de la République",
  postalCode: "75001",
  city: "Paris",
  country: "FR",
  language: "fr",
  occupation: "Entrepreneur",
  avatar: "",
};

export default function SettingsPage() {
  const router = useRouter();
  const { t, changeLanguage, currentLanguage, isClient } = useTranslation();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [, forceUpdate] = useState(0);
  const [mounted, setMounted] = useState(false);
  const [isChangingLanguage, setIsChangingLanguage] = useState(false);
  
  // Éviter les erreurs d'hydratation en chargeant uniquement côté client
  useEffect(() => {
    // Attendre que le client soit prêt ET que i18n soit synchronisé
    if (isClient) {
      // Utiliser requestAnimationFrame pour s'assurer que l'hydratation est complète
      requestAnimationFrame(() => {
        setMounted(true);
      });
    }
  }, [isClient]);
  
  // Forcer le re-render quand la langue change
  useEffect(() => {
    const handleLanguageChange = () => {
      forceUpdate(prev => prev + 1);
    };
    i18n.on('languageChanged', handleLanguageChange);
    return () => {
      i18n.off('languageChanged', handleLanguageChange);
    };
  }, []);
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const [isComingSoonModalOpen, setIsComingSoonModalOpen] = useState(false);
  const [isDevicesModalOpen, setIsDevicesModalOpen] = useState(false);
  const [isInvitationsModalOpen, setIsInvitationsModalOpen] = useState(false);
  const [isEditProfileModalOpen, setIsEditProfileModalOpen] = useState(false);
  const [isSupportModalOpen, setIsSupportModalOpen] = useState(false);
  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [copied, setCopied] = useState(false);
  const [invitationsCount] = useState(3); // Mock pour l'instant, plus tard : calculer depuis skanesLast24h
  const [streakDays, setStreakDays] = useState(0);
  const [memberSince, setMemberSince] = useState('Jan 2026');
  const [userProfile, setUserProfile] = useState({
    ...mockUser,
    language: currentLanguage || "fr", // Synchroniser avec i18n
  });
  const [userId, setUserId] = useState<string>('');

  // Load from localStorage on mount
  useEffect(() => {
    const savedNotifications = localStorage.getItem("notificationsEnabled");
    const savedLanguage = localStorage.getItem("language");
    const savedProfile = localStorage.getItem("userProfile");
    const savedUser = localStorage.getItem("user");

    if (savedLanguage && currentLanguage !== savedLanguage) {
      // S'assurer que la langue est bien chargée dans i18n
      changeLanguage(savedLanguage);
    }

    if (savedNotifications !== null) {
      setNotificationsEnabled(savedNotifications === "true");
    }
    if (savedProfile) {
      try {
        const profile = JSON.parse(savedProfile);
        setUserProfile((prev) => ({ ...prev, ...profile }));
      } catch (e) {
        console.error("Error parsing saved profile:", e);
      }
    }
    
    // Récupérer le userId depuis localStorage ou utiliser username comme fallback
    if (savedUser) {
      try {
        const user = JSON.parse(savedUser);
        // Utiliser user_id si disponible, sinon username, sinon email
        setUserId(user.user_id || user.id || user.username || user.email || mockUser.username);
      } catch (e) {
        console.error("Error parsing saved user:", e);
        setUserId(mockUser.username);
      }
    } else {
      setUserId(mockUser.username);
    }

    // Calculer le streak et la date d'inscription
    setStreakDays(calculateStreak());
    setMemberSince(getMemberSince());
  }, []);

  // Attacher les event listeners pour tous les boutons
  useEffect(() => {
    const attachListeners = () => {
      // Language est maintenant géré directement par le select React, pas besoin d'event listener

      // Bouton Invitations
      const invitationsBtn = document.querySelector('[data-setting="invitations"]');
      if (invitationsBtn && !invitationsBtn.hasAttribute('data-listener-attached')) {
        invitationsBtn.setAttribute('data-listener-attached', 'true');
        invitationsBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          setIsInvitationsModalOpen(true);
        });
      }

      // Bouton Support
      const supportBtn = document.querySelector('[data-setting="support"]');
      if (supportBtn && !supportBtn.hasAttribute('data-listener-attached')) {
        supportBtn.setAttribute('data-listener-attached', 'true');
        supportBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          setIsSupportModalOpen(true);
        });
      }

      // Bouton Log Out
      const logOutBtn = document.querySelector('[data-setting="logout"]');
      if (logOutBtn && !logOutBtn.hasAttribute('data-listener-attached')) {
        logOutBtn.setAttribute('data-listener-attached', 'true');
        logOutBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          handleLogOut();
        });
      }

      // Bouton Copy Referral
      const copyBtn = document.querySelector('[data-setting="copy-referral"]');
      if (copyBtn && !copyBtn.hasAttribute('data-listener-attached')) {
        copyBtn.setAttribute('data-listener-attached', 'true');
        copyBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          handleCopyReferral();
        });
      }

      // Toggle Notifications - maintenant géré directement par onClick React, pas besoin d'addEventListener

      // Bouton Edit Profile
      const editProfileBtn = document.querySelector('[data-profile="edit"]');
      if (editProfileBtn && !editProfileBtn.hasAttribute('data-listener-attached')) {
        editProfileBtn.setAttribute('data-listener-attached', 'true');
        editProfileBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          setIsEditProfileModalOpen(true);
        });
      }
    };

    attachListeners();
    setTimeout(attachListeners, 100);
    setTimeout(attachListeners, 500);
  }, [notificationsEnabled]);

  // Save notifications to localStorage
  useEffect(() => {
    localStorage.setItem("notificationsEnabled", notificationsEnabled.toString());
  }, [notificationsEnabled]);

  const handleLanguageSelect = async (newLang: string) => {
    if (newLang === currentLanguage || isChangingLanguage) return;
    
    // Sauvegarder dans localStorage et recharger
    // Le I18nProvider va automatiquement charger la nouvelle langue depuis localStorage au rechargement
    localStorage.setItem('language', newLang);
    window.location.reload();
  };

  const handleCopyReferral = async () => {
    try {
      await navigator.clipboard.writeText(mockUser.referralCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy:", err);
    }
  };

  const handleAvatarClick = () => {
    console.log("Upload photo");
  };

  const handleLogOut = () => {
    console.log("Logging out...");
  };

  // Swipe gestures pour naviguer entre les pages
  const swipeRef = useSwipe({
    onSwipeLeft: () => {
      // Swipe vers la gauche = aller vers Home
      router.push("/");
    },
    onSwipeRight: () => {
      // Swipe vers la droite = aller vers Skane
      router.push("/skane");
    },
    threshold: 50,
    velocityThreshold: 0.3,
  });

  // Forcer le re-render complet quand la langue change
  if (!mounted) {
    return (
      <SafeAreaContainer currentPage="settings">
        <main className="relative min-h-screen-safe bg-nokta-one-black">
          <div className="px-4 pt-8 pb-8">
            <div className="animate-pulse text-white text-center">Loading...</div>
          </div>
        </main>
      </SafeAreaContainer>
    );
  }

  return (
    <SafeAreaContainer currentPage="settings" key={`settings-${currentLanguage}-${Date.now()}`}>
      <main 
        ref={swipeRef}
        className="relative min-h-screen-safe bg-nokta-one-black"
      >
        <div className="px-4 pt-12 pb-24">
        {/* Header */}
        <h1 
          className="text-center text-xl font-light text-white tracking-widest mb-8"
          suppressHydrationWarning
        >
          {t("settings.profile")}
        </h1>

        {/* Section Profil avec gamification */}
        <div className="bg-white/5 rounded-2xl p-4 mb-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center">
              {userProfile.avatar ? (
                <img src={userProfile.avatar} alt={userProfile.username} className="w-full h-full rounded-full object-cover" />
              ) : (
                <span className="text-2xl">👤</span>
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-white">@{userProfile.username}</span>
                <button 
                  onClick={() => setIsEditProfileModalOpen(true)}
                  className="p-1 rounded-full hover:bg-white/10"
                >
                  <Edit2 size={14} className="text-white/60" />
                </button>
              </div>
              <p className="text-sm text-white/50">{userProfile.email}</p>
            </div>
          </div>
          
          {/* Stats */}
          <div className="mt-4 pt-4 border-t border-white/10 flex gap-6">
            <div className="flex items-center gap-2">
              <span className="text-orange-500">🔥</span>
              <span className="text-sm text-white">{streakDays} {t("profile.streakDays")}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-green-500">✓</span>
              <span className="text-sm text-white/60">{t("profile.memberSince")} {memberSince}</span>
            </div>
          </div>
        </div>

        {/* Rappels - Simplifié */}
        <div className="bg-white/5 rounded-2xl p-4 mb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bell size={20} className="text-blue-400" />
              <div>
                <p className="font-medium text-white">{t("settings.dailyReminders")}</p>
                <p className="text-xs text-white/50">{t("settings.dailyRemindersDescription")}</p>
              </div>
            </div>
            <motion.button
              onClick={() => setNotificationsEnabled(!notificationsEnabled)}
              className={`relative w-12 h-7 rounded-full transition-colors ${
                notificationsEnabled ? 'bg-blue-500' : 'bg-white/20'
              }`}
              whileTap={{ scale: 0.95 }}
            >
              <motion.div
                className={`w-5 h-5 bg-white rounded-full transition-transform mx-1 ${
                  notificationsEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </motion.button>
          </div>
          
          {/* Lien pour personnaliser (discret) */}
          {notificationsEnabled && (
            <button 
              onClick={() => setShowScheduleModal(true)}
              className="mt-3 text-xs text-white/40 hover:text-white/60 flex items-center gap-1"
            >
              {t("settings.customizeSchedule")} <ChevronRight size={12} />
            </button>
          )}
        </div>

        {/* Préférences */}
        <div className="space-y-2 mb-4">
          <SettingsRow 
            icon={Globe} 
            label={t("settings.language")} 
            value={LANGUAGES.find(l => l.code === currentLanguage)?.name || 'Français'}
            hasArrow
            onClick={() => {
              // Ouvrir modal de langue ou changer directement
              const newLang = currentLanguage === 'fr' ? 'en' : 'fr';
              handleLanguageSelect(newLang);
            }}
          />
          <SettingsRow 
            icon={Smartphone} 
            label={t("settings.connectedDevices")} 
            hasArrow
            onClick={() => setIsDevicesModalOpen(true)}
          />
        </div>

        {/* Social */}
        <div className="space-y-2 mb-4">
          <SettingsRow 
            icon={UserPlus} 
            label={t("profile.inviteFriends")} 
            hasArrow 
            highlight
            onClick={() => setIsInvitationsModalOpen(true)}
          />
        </div>

        {/* Aide */}
        <div className="space-y-2 mb-4">
          <SettingsRow 
            icon={HelpCircle} 
            label={t("faq.title")} 
            hasArrow
            onClick={() => router.push("/faq")}
          />
          <SettingsRow 
            icon={MessageCircle} 
            label={t("support.contactUs")} 
            hasArrow
            onClick={() => setIsSupportModalOpen(true)}
          />
        </div>

        {/* Menu "Plus" - Options avancées cachées */}
        <div className="space-y-2 mb-4">
          <button 
            onClick={() => setShowMoreOptions(!showMoreOptions)}
            className="w-full flex items-center justify-between p-4 rounded-2xl bg-white/5 hover:bg-white/10 transition-colors"
          >
            <div className="flex items-center gap-3">
              <MoreHorizontal size={20} className="text-white/60" />
              <span className="text-white">{t("settings.more")}</span>
            </div>
            <ChevronDown 
              size={18} 
              className={`text-white/30 transition-transform ${showMoreOptions ? 'rotate-180' : ''}`} 
            />
          </button>
          
          {/* Options dépliables */}
          {showMoreOptions && (
            <div className="ml-4 space-y-2 animate-in slide-in-from-top-2 duration-200">
              <SettingsRow 
                icon={BookOpen} 
                label="Nokta Dictionary" 
                hasArrow 
                subtle
                onClick={() => router.push("/dictionary")}
              />
              {userId && (
                <SettingsRow 
                  icon={Users} 
                  label={t("settings.partnershipManagement")} 
                  hasArrow 
                  subtle
                  onClick={() => {
                    // Ouvrir modal partenariats
                    setIsComingSoonModalOpen(true);
                  }}
                />
              )}
              {userId && (
                <SettingsRow 
                  icon={Download} 
                  label={t("settings.exportData")} 
                  hasArrow 
                  subtle
                  onClick={async () => {
                    const { exportUserData } = await import("@/lib/hooks/useConsent");
                    const blob = await exportUserData(userId);
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = `nokta-export-${Date.now()}.json`;
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                />
              )}
            </div>
          )}
        </div>

        {/* Légal (discret) */}
        {userId && (
          <div className="pt-4 mb-4">
            <SettingsRow 
              icon={Shield} 
              label={t("privacy.sectionTitle")} 
              hasArrow 
              subtle
              onClick={() => {
                // Ouvrir modal confidentialité
                setIsComingSoonModalOpen(true);
              }}
            />
          </div>
        )}

        {/* Déconnexion (très discret) */}
        <div className="pt-8 text-center">
          <button 
            onClick={handleLogOut}
            className="text-sm text-white/30 hover:text-white/50 flex items-center gap-2 mx-auto"
          >
            <LogOut size={14} />
            {t("settings.logOut")}
          </button>
          <p className="mt-4 text-xs text-white/20">v1.2.0 · Nokta One</p>
        </div>
      </div>

        {/* Modal pour personnaliser les horaires */}
        {showScheduleModal && notificationsEnabled && (
          <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white/10 backdrop-blur-md rounded-2xl p-6 max-w-md w-full border border-white/20"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-semibold">{t("settings.notificationSchedule")}</h3>
                <button
                  onClick={() => setShowScheduleModal(false)}
                  className="text-white/60 hover:text-white"
                >
                  <ChevronRight size={20} className="rotate-90" />
                </button>
              </div>
              <NotificationScheduler
                userId={userId || null}
                notificationsEnabled={notificationsEnabled}
              />
            </motion.div>
          </div>
        )}

      {/* Modals */}

      <ComingSoonModal
        isOpen={isComingSoonModalOpen}
        onClose={() => setIsComingSoonModalOpen(false)}
      />

      <ConnectedDevicesModal
        isOpen={isDevicesModalOpen}
        onClose={() => setIsDevicesModalOpen(false)}
      />

      <InvitationsModal
        isOpen={isInvitationsModalOpen}
        onClose={() => setIsInvitationsModalOpen(false)}
        invitationsCount={invitationsCount}
        referralCode={mockUser.referralCode}
      />

      <EditProfileModal
        isOpen={isEditProfileModalOpen}
        onClose={() => setIsEditProfileModalOpen(false)}
        onSave={(data) => {
          setUserProfile((prev) => ({ ...prev, ...data }));
          // Synchroniser la langue avec i18n si elle a changé
          if (data.language && data.language !== currentLanguage) {
            changeLanguage(data.language);
          }
          // Show toast notification
          console.log("Profil mis à jour !");
        }}
        initialData={userProfile}
      />

      <SupportModal
        isOpen={isSupportModalOpen}
        onClose={() => setIsSupportModalOpen(false)}
        userEmail={userProfile.email}
        username={userProfile.username}
        userId={userProfile.username}
      />

      </main>
    </SafeAreaContainer>
  );
}

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useTranslation } from "@/lib/hooks/useTranslation";
import SkaneScan from "@/components/skane/SkaneScan";
import { FLOW_V1_ENABLED } from "@/lib/flowV1";

export default function SkanePage() {
  const router = useRouter();
  const { t } = useTranslation();

  const handleSkaneComplete = (selfieUrl: string) => {
    // Extraire le base64 sans le préfixe data:image si présent
    let imageBase64 = selfieUrl;
    if (selfieUrl.startsWith('data:image')) {
      imageBase64 = selfieUrl.split(',')[1] || selfieUrl;
    }
    
    // Stocker dans sessionStorage (format base64 pur pour l'API)
    sessionStorage.setItem("skane_captured_image", imageBase64);
    
    // Récupérer le mode invité depuis localStorage
    const isGuestMode = localStorage.getItem("guestMode") === "true";
    sessionStorage.setItem("skane_guest_mode", isGuestMode.toString());
    
    // Rediriger vers le flow approprié
    if (FLOW_V1_ENABLED) {
      router.push("/skane/flowV1/analyzing");
    } else {
      router.push("/skane/analyzing");
    }
  };

  return (
    <SkaneScan 
      onSkaneComplete={handleSkaneComplete}
    />
  );
}

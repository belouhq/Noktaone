# Guide de démarrage - Problème de permissions réseau macOS

## ✅ RÉSOLU
Le problème de permissions réseau a été résolu. Le serveur fonctionne maintenant sur `localhost:3000`.

## Problème (résolu)
L'erreur `EPERM: operation not permitted` indiquait que macOS bloquait l'accès réseau à Node.js.

## Solution

### 1. Autoriser l'accès réseau (OBLIGATOIRE)

1. Ouvrir **Réglages Système** (ou **System Settings**)
2. Aller dans **Confidentialité et sécurité** (ou **Privacy & Security**)
3. **Cliquer sur "Réseau local"** (ou **"Local Network"**) - vous verrez "(48 applications)" à côté
4. Dans la liste qui s'ouvre, chercher :
   - **Terminal** (ou **iTerm2** si vous l'utilisez)
   - **Cursor** (ou **Visual Studio Code** si vous l'utilisez)
   - **Node.js** (peut apparaître comme "node")
5. **Cocher la case** à côté de chaque application pour autoriser l'accès réseau local
6. **Si Terminal/Cursor/Node.js n'apparaît PAS dans la liste** (c'est votre cas) :
   - **Fermer complètement Cursor** (Cmd+Q, pas juste fermer la fenêtre)
   - **Rouvrir Cursor**
   - Dans le terminal intégré de Cursor, taper : `npm run dev`
   - **macOS affichera automatiquement une popup** demandant l'autorisation réseau
   - **Cliquer sur "Autoriser"** dans la popup
   - Revenir dans Réglages Système → Confidentialité et sécurité → Réseau local
   - **Cursor/Terminal devrait maintenant apparaître** dans la liste
   - **Cocher la case** pour activer l'accès réseau local

### 2. Redémarrer complètement

- Fermer **TOUS** les terminaux et Cursor
- Rouvrir Cursor
- Relancer `npm run dev`

### 3. Vérifier les processus

```bash
# Vérifier si un processus utilise le port 3000
lsof -i :3000

# Si oui, le tuer
kill -9 <PID>
```

### 4. Alternative : Utiliser un autre port

Si le problème persiste après avoir autorisé l'accès réseau :

```bash
PORT=8080 npm run dev
```

Puis accéder à `http://localhost:8080`

## Vérification

Après avoir autorisé l'accès réseau, le serveur devrait démarrer avec :

```
✓ Ready in X ms
○ Local: http://localhost:3000
```

Si vous voyez toujours `EPERM`, le problème vient des permissions macOS, pas du code.

## Solution alternative : Utiliser Terminal natif macOS

Si Cursor ne déclenche pas la popup d'autorisation :

1. **Ouvrir Terminal** (application native macOS, pas le terminal intégré de Cursor)
2. Naviguer vers le projet :
   ```bash
   cd "/Users/benjaminbel/nokta-app/Nokta One"
   ```
3. Lancer le test :
   ```bash
   node test-server.js
   ```
4. **macOS devrait afficher une popup** → Cliquer sur **"Autoriser"**
5. Une fois autorisé, vous pouvez utiliser Cursor normalement

Terminal natif déclenche souvent mieux les demandes de permissions macOS que les terminaux intégrés des éditeurs.
